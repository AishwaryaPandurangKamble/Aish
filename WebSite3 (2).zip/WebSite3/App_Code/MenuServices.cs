﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for MenuServices
/// </summary>
public class MenuServices
{
    public static item[] itemList = new item[4]
            {
        new item(1,"Chicken Tandoori",10,20),
        new item(2,"Veg Biryani",10,25),
        new item(3,"Non-Veg Biryani",20,35),
        new item(4,"Chole Puri",25,50)
             };
        public void abc(GridView gc)
        {
            gc.DataSource = itemList;
            gc.DataBind();
        }

    }
