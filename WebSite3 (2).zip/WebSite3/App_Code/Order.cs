﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{

    public int OrderId { get; set; }
    public DateTime OrderDate { get; set; }
    public List<item> CorderCart { get; set; }
    public Order()
    {
        OrderId = new Random().Next(1, 100);
        OrderDate = DateTime.Now.Date;
        //
        // TODO: Add constructor logic here
        //
    }

}

