﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for item
/// </summary>
public class item
{

    public item()
    {

    }
    public int itemId { get; set; }
    public string itemName { get; set; }
    public int itemPreTime { get; set; }
    public float itemPrice { get; set; }

        public item(int id, string name, int time, float price)
        {
            itemId = id;
            itemName = name;
            itemPreTime = time;
            itemPrice = price;
        }
    }

