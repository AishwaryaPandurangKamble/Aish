﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class LoginPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["error"] != null)
        {
            Response.Write("<script> alert('Please login first !!') </script>");

            ViewState["nextPage"] = Request.QueryString["page"].ToString();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select UserName,Password,UserType  from Registrationtable where UserName=@UserName and Password=@Password";
            cmd.Parameters.AddWithValue("UserName", txt_unm.Text);
            cmd.Parameters.AddWithValue("Password", TextBox1.Text);
            cmd.Parameters.AddWithValue("UserType", DropDownList1.Text);


            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["username"] = dr["username"].ToString();
                Session["Password"] = dr["Password"].ToString();
                Session["usertype"] = dr["usertype"].ToString();

                Label2.Text = "Login Successfull";
                txt_unm.Text = "";
                if (ViewState["nextPage"] == null)
                {
                    Response.Redirect("index.aspx");
                }
                else
                {
                    Response.Redirect(ViewState["nextPage"].ToString());
                }
            }
            else
            {
                msg.Visible = true;
                msg.Text = "User name / password not matched !!";

            }
            dr.Close();
            con.Close();
        }
    }



    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}