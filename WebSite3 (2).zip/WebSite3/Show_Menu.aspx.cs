﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;

public partial class Show_Menu : System.Web.UI.Page
{
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)

    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("LoginPage.aspx?error=403&page=index.aspx");
        }
        MenuServices ms = new MenuServices();

        ms.abc(Grid1);
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

        if (!IsPostBack)
        
            Displaydb();
           
    }
    private void Displaydb()
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText= "SELECT* from item123";
            SqlDataReader dr = cmd.ExecuteReader();

            Gridview2.DataSource = dr;
            Gridview2.DataBind();
            con.Close();
        }


    }  
                    
                
  }
       
    



    


