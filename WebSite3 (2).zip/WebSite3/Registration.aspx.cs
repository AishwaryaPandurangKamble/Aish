﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
       con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert into Registrationtable values(@UserName,@Password,@UserType,@ContactNo,@Address)";
            //cmd.Parameters.AddWithValue("ID");

            cmd.Parameters.AddWithValue("UserName", txt_user.Text);
            cmd.Parameters.AddWithValue("Password", txt_pwd.Text);
            cmd.Parameters.AddWithValue("UserType", dd_type.Text);
            cmd.Parameters.AddWithValue("ContactNo", txt_cnt.Text);
            cmd.Parameters.AddWithValue("Address", txt_add.Text);
           cmd.ExecuteNonQuery();
            Console.WriteLine("Data Inserted");
            

            con.Close();
        }
    }
}