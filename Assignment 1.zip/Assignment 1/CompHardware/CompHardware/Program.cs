﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CompHardware
{
    class ComputerHardware
    {
        public string Name { get; set; }
        public int Code { get; set; }
        public float Price { get; set; }
        public int Warranty { get; set; }
        public string Manufacturer { get; set; }
        public float MRP { get; set; }
        public DateTime WarrantyEndDate { get; set; }
       

       

        
    }

    class Program
    {
        
            List<ComputerHardware> ls = new List<ComputerHardware>()
            {
                new ComputerHardware() {Name="MotherBoard",Code=101,Price=1500,Warranty=5,MRP=1800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-5-2018")},
                new ComputerHardware() {Name="Mouse",Code=102,Price=500,Warranty=12,MRP=800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-6-2018") },
                new ComputerHardware() {Name="Keyboard",Code=103,Price=600,Warranty=5,MRP=900, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("4-5-2018")},
                new ComputerHardware() {Name="Monitor",Code=104,Price=2500,Warranty=15,MRP=2800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("17-2-2018")},
                new ComputerHardware() {Name="MotherBoard",Code=105,Price=1500,Warranty=15,MRP=1800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-11-2018")},
                new ComputerHardware() {Name="Ram",Code=106,Price=200,Warranty=24,MRP=300, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-5-2019")},
                new ComputerHardware() {Name="CPU",Code=107,Price=3500,Warranty=25,MRP=3800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-5-2018")},
                new ComputerHardware() {Name="Monitor",Code=108,Price=2500,Warranty=12,MRP=2800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-5-2019")},
                new ComputerHardware() {Name="Mouse",Code=109,Price=500,Warranty=12,MRP=800, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-1-2020")},
                new ComputerHardware() {Name="Keyboard",Code=110,Price=600,Warranty=19,MRP=900, Manufacturer="Rashmi",WarrantyEndDate=Convert.ToDateTime("10-5-2019")},

            };
        void Display()
        {
            var search = from data in ls.ToList()
                         where data.Warranty > 15
                         orderby data.Price descending
                         select data;
            foreach (var item in search)
            {
                Console.WriteLine($"Component Name:{item.Name}\n Code:{item.Code} \n Price:{item.Price}\n Warranty:{item.Warranty}\n MRP:{item.MRP}\n Manufacturer:{item.Manufacturer}\n WarrantyEndDate:{item.WarrantyEndDate} ");
            }
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Display();
            Console.ReadLine();
         }
}
}
