﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace accident
{
    public partial class Form1 : Form
    {
        DataClasses1DataContext ctx = new DataClasses1DataContext();

        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Accident_Claim1 acc = new Accident_Claim1();
            acc.PolicyNo = pcno.Text;
            acc.VechicleNo = vcno.Text;
            acc.OwnerName = ownm.Text;
            acc.AccidentLocation = accloc.Text;
            acc.PolicyRegLocation = regloc.Text;
            acc.NoMemberInjured = nomember.Text;
            ctx.Accident_Claim1s.InsertOnSubmit(acc);

            ctx.SubmitChanges();

            Console.WriteLine("Data Inserted");
            claimNo.Text = Convert.ToString(acc.ClaimNo);
            // =Convert.ToInt32(acc.CliamNo);

        }

        private void button4_Click(object sender, EventArgs e)
        {

            // To delete a record 


            var acc = ctx.Accident_Claim1s.ToList().Where(x => x.ClaimNo == Convert.ToInt32(claimNo.Text));

            if (acc != null)
            {
                ctx.Accident_Claim1s.DeleteAllOnSubmit(acc);
                ctx.SubmitChanges();
                Console.WriteLine("Delete success");
            }
            else
            {
                Console.WriteLine("ID not found !!");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = true;

            Accident_Claim1 acc = new Accident_Claim1();

            var value = ctx.Accident_Claim1s.Where(x => x.ClaimNo == Convert.ToInt32(claimNo.Text)).First();

            if (value != null)
            {

                pcno.Text = value.PolicyNo;
                vcno.Text = value.VechicleNo;
                ownm.Text = value.OwnerName;
                accloc.Text = value.AccidentLocation;
                regloc.Text = value.PolicyRegLocation;
                nomember.Text = value.NoMemberInjured;

            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Accident_Claim1 acc = new Accident_Claim1();

            var value = ctx.Accident_Claim1s.Where(x => x.ClaimNo == Convert.ToInt32(claimNo.Text)).First();

            if (value != null)
            {
               value.PolicyNo = pcno.Text;
                value.VechicleNo = vcno.Text;
                value.OwnerName = ownm.Text;
                value.AccidentLocation = accloc.Text;
                value.PolicyRegLocation = regloc.Text;
                value.NoMemberInjured = nomember.Text;


                ctx.SubmitChanges();

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var acc = ctx.Accident_Claim1s.ToList().Where(x => x.ClaimNo == Convert.ToInt32(claimNo.Text));

            using (TextWriter tw = new StreamWriter("C:/Users/aishwarya.kamble/Documents/LINQ/accident.txt"))
            {
                foreach (var item in acc)
                {
                    tw.WriteLine(string.Format("PolicyNo:{0}    VechicleNo: {1}   OwnerName :{2}      PolicyRegLocation:{3}       AccidentLocation:{4}     NoMemberInjured:{5}", item.PolicyNo, item.VechicleNo,item.OwnerName,item.PolicyRegLocation,item.AccidentLocation,item.NoMemberInjured));
                }
            }
        }
    }
}
