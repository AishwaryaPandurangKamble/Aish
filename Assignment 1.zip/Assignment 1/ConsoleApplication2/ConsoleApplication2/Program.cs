﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument XDOC = XDocument.Load("C:/Users/aishwarya.kamble/Documents/LINQ/Assignment 1/ConsoleApplication2/ConsoleApplication2/XMLFile2.xml");

       var data=     from q in XDOC.Descendants("ComputerHardware").Elements("Product")
            where (int)q.Element("Price") > 1000
            from q1 in q.Elements("Warrnty")
            where (int)q.Element("Warrnty") < 2
            select q.Value;

            foreach (var item in data)
            {
                Console.WriteLine(item);
            }
        }

    }
}

